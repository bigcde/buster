import { describe, expect, it } from 'vitest';
import { ComboTracker, judgeOffset, powerFor, spawnDelayBeats } from '../src/core/judge';
import { beatFraction, beatIndexAt, median, nearestBeatOffsetMs } from '../src/core/beatMath';

describe('judgeOffset', () => {
  it('judges window boundaries', () => {
    expect(judgeOffset(0)).toBe('PERFECT');
    expect(judgeOffset(80)).toBe('PERFECT');
    expect(judgeOffset(-80)).toBe('PERFECT');
    expect(judgeOffset(81)).toBe('GOOD');
    expect(judgeOffset(-81)).toBe('GOOD');
    expect(judgeOffset(140)).toBe('GOOD');
    expect(judgeOffset(-140)).toBe('GOOD');
    expect(judgeOffset(141)).toBe('MISS');
    expect(judgeOffset(-141)).toBe('MISS');
  });

  it('maps judgement to power and spawn delay', () => {
    expect(powerFor('PERFECT')).toBe(1.5);
    expect(powerFor('GOOD')).toBe(1.0);
    expect(powerFor('MISS')).toBe(0.7);
    expect(spawnDelayBeats('MISS')).toBe(1);
    expect(spawnDelayBeats('PERFECT')).toBe(0);
  });
});

describe('ComboTracker', () => {
  it('goes ON FIRE after 3 PERFECTs', () => {
    const c = new ComboTracker(3);
    c.register('PERFECT');
    c.register('PERFECT');
    expect(c.onFire).toBe(false);
    c.register('PERFECT');
    expect(c.onFire).toBe(true);
    expect(c.best).toBe(3);
  });

  it('resets on GOOD or MISS', () => {
    const c = new ComboTracker(3);
    c.register('PERFECT');
    c.register('PERFECT');
    c.register('GOOD');
    expect(c.streak).toBe(0);
    c.register('PERFECT');
    c.register('MISS');
    expect(c.streak).toBe(0);
    expect(c.onFire).toBe(false);
    expect(c.best).toBe(2);
  });

  it('ON FIRE discounts one card by 1, never below 1', () => {
    const c = new ComboTracker(3);
    ['PERFECT', 'PERFECT', 'PERFECT'].forEach(() => c.register('PERFECT'));
    expect(c.consumeDiscount(3)).toBe(2);
    expect(c.onFire).toBe(false);
    expect(c.consumeDiscount(3)).toBe(3);

    ['PERFECT', 'PERFECT', 'PERFECT'].forEach(() => c.register('PERFECT'));
    expect(c.consumeDiscount(1)).toBe(1);
  });
});

describe('beatMath', () => {
  const bpm = 120; // 0.5 s per beat

  it('finds the nearest beat offset', () => {
    expect(nearestBeatOffsetMs(1.0, bpm)).toBeCloseTo(0);
    expect(nearestBeatOffsetMs(1.04, bpm)).toBeCloseTo(40);
    expect(nearestBeatOffsetMs(0.96, bpm)).toBeCloseTo(-40);
  });

  it('computes beat index and fraction', () => {
    expect(beatIndexAt(1.24, bpm)).toBe(2);
    expect(beatFraction(1.25, bpm)).toBeCloseTo(0.5);
    expect(beatFraction(-0.25, bpm)).toBeCloseTo(0.5);
  });

  it('computes the median', () => {
    expect(median([])).toBe(0);
    expect(median([5, 1, 3])).toBe(3);
    expect(median([4, 1, 3, 2])).toBe(2.5);
  });
});
