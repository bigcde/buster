import { describe, expect, it } from 'vitest';
import { isSongOver, phaseAt, sectionAt } from '../src/core/phases';

describe('phases', () => {
  it('finds the section at boundary times', () => {
    expect(sectionAt(0).name).toBe('intro');
    expect(sectionAt(19.99).name).toBe('intro');
    expect(sectionAt(20).name).toBe('verse');
    expect(sectionAt(70).name).toBe('buildup');
    expect(sectionAt(90).name).toBe('drop');
    expect(sectionAt(110).name).toBe('outro');
    expect(sectionAt(150).name).toBe('outro');
    expect(sectionAt(-1).name).toBe('intro');
  });

  it('reports song end', () => {
    expect(isSongOver(149.99)).toBe(false);
    expect(isSongOver(150)).toBe(true);
  });

  it('sets Groove speed and drop availability per phase', () => {
    expect(phaseAt(10).grooveBeatsPerPoint).toBe(4);
    expect(phaseAt(80).grooveBeatsPerPoint).toBe(2);
    expect(phaseAt(130).grooveBeatsPerPoint).toBe(2);
    expect(phaseAt(100).dropAbilityAvailable).toBe(true);
    expect(phaseAt(60).dropAbilityAvailable).toBe(false);
    expect(phaseAt(80).progress).toBeCloseTo(0.5);
  });
});
