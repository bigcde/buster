# Beat Busters — prototype

1v1 strategy game where you drop units **on the beat**. Full spec: [BEAT_BUSTERS_SPEC.md](BEAT_BUSTERS_SPEC.md).

## Status

- [x] **Milestone 1** — beat clock, synthesized song, beat ring, tap judging, calibration
- [ ] Milestone 2 — towers
- [ ] Milestone 3 — units, Groove, cards
- [ ] Milestone 4 — AI, phases, win conditions, Bass Drop
- [ ] Milestone 5 — polish + telemetry

## Run

```bash
npm install
npm run dev      # opens on your network too: use the "Network" URL on your phone
npm test
```

Play on a phone: phone and computer on the same Wi-Fi, open the Network URL that `npm run dev` prints, turn the phone sideways.

## How to play (Milestone 1)

1. Tap to start (unlocks audio).
2. First run: calibration. Listen to 4 clicks, then tap along with the next 8.
3. The match screen plays a 2:30 song (intro → verse → build-up → drop → outro).
   Tap anywhere when the white ring lands on the yellow ring. You get PERFECT / GOOD / MISS and the offset in ms.

## Tuning

All numbers are in `src/config/`:

| What | Where |
| --- | --- |
| Judge windows (±80 / ±140 ms) | `constants.ts` → `JUDGE` |
| BPM, length, section times | `song.ts` → `SONG` |
| Groove rates | `constants.ts` → `GROOVE` |
| Calibration | `constants.ts` → `CALIBRATION` |

Calibration result is stored in `localStorage` (`bb.latencyMs`). Use "Kalibre et" to redo it.

## Code layout

- `src/core/` — pure logic, no Phaser (tested in `tests/`)
- `src/audio/` — AudioContext, beat clock, procedural synth
- `src/scenes/`, `src/ui/` — Phaser scenes and widgets

Timing note: judging uses the pointer event's own timestamp mapped to AudioContext time (`getOutputTimestamp`), never frame time.
