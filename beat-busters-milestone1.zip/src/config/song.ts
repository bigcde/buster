export type SectionName = 'intro' | 'verse' | 'buildup' | 'drop' | 'outro';

export interface Section {
  name: SectionName;
  /** Start time in seconds (inclusive). */
  start: number;
  /** End time in seconds (exclusive). */
  end: number;
}

export interface SongDef {
  bpm: number;
  durationSec: number;
  sections: Section[];
}

export const SONG: SongDef = {
  bpm: 110,
  durationSec: 150,
  sections: [
    { name: 'intro', start: 0, end: 20 },
    { name: 'verse', start: 20, end: 70 },
    { name: 'buildup', start: 70, end: 90 },
    { name: 'drop', start: 90, end: 110 },
    { name: 'outro', start: 110, end: 150 },
  ],
};

/** Display labels for the UI. */
export const SECTION_LABELS: Record<SectionName, string> = {
  intro: 'INTRO',
  verse: 'VERSE',
  buildup: 'BUILD-UP',
  drop: 'DROP',
  outro: 'OUTRO',
};
