// All tunable numbers live here.

export const GAME = {
  width: 1280,
  height: 720,
  background: '#14121f',
};

/** Rhythm judging windows (absolute offset from the nearest beat, in ms). */
export const JUDGE = {
  perfectMs: 80,
  goodMs: 140,
  /** PERFECTs in a row needed for ON FIRE. */
  comboForOnFire: 3,
};

/** Unit power multiplier per judge result (applied to HP and damage). */
export const POWER = {
  PERFECT: 1.5,
  GOOD: 1.0,
  MISS: 0.7,
} as const;

export const GROOVE = {
  max: 10,
  start: 5,
  /** Beats needed for +1 Groove in normal phases. */
  normalBeatsPerPoint: 4,
  /** Beats needed for +1 Groove in buildup and outro. */
  fastBeatsPerPoint: 2,
};

export const AUDIO = {
  /** How far ahead the synth schedules notes (s). */
  lookaheadSec: 0.1,
  /** How often the scheduler runs (ms). */
  schedulerIntervalMs: 25,
  /** Delay between pressing start and the first beat (s). */
  startLeadSec: 1.0,
  masterVolume: 0.8,
};

export const CALIBRATION = {
  bpm: 100,
  leadInBeats: 4,
  tapBeats: 8,
  /** Taps further than this from a click are ignored (ms). */
  maxTapOffsetMs: 300,
  /** Minimum valid taps to trust the result. */
  minTaps: 4,
};

export const FEEDBACK = {
  vibrateMs: 15,
};

export const STORAGE_KEYS = {
  latencyMs: 'bb.latencyMs',
  vibration: 'bb.vibration',
};
