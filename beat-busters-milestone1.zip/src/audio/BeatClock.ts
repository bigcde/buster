import { beatFraction, beatIndexAt, nearestBeatOffsetMs, secondsPerBeat } from '../core/beatMath';
import { ctxTimeAt } from './context';

/**
 * Song clock based on the AudioContext (never on frame time).
 * songTime = heard AudioContext time - song start - calibrated latency.
 */
export class BeatClock {
  private startTime = Number.POSITIVE_INFINITY;

  constructor(
    private readonly ctx: AudioContext,
    public readonly bpm: number,
    public latencyMs = 0,
  ) {}

  /** Song beat 0 happens at this AudioContext time. */
  start(atCtxTime: number): void {
    this.startTime = atCtxTime;
  }

  get spb(): number {
    return secondsPerBeat(this.bpm);
  }

  /** Song time (s) for a performance.now()-domain timestamp (e.g. event.timeStamp). */
  songTime(perfMs?: number): number {
    return ctxTimeAt(this.ctx, perfMs) - this.startTime - this.latencyMs / 1000;
  }

  beatIndex(t: number): number {
    return beatIndexAt(t, this.bpm);
  }

  offsetMs(t: number): number {
    return nearestBeatOffsetMs(t, this.bpm);
  }

  fraction(t: number): number {
    return beatFraction(t, this.bpm);
  }
}
