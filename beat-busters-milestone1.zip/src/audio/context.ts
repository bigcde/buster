// One shared AudioContext + helpers for timing and stored settings.
import { STORAGE_KEYS } from '../config/constants';

let ctx: AudioContext | null = null;

export function getAudioContext(): AudioContext {
  if (!ctx) {
    const Ctor: typeof AudioContext =
      window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    ctx = new Ctor({ latencyHint: 'interactive' });
  }
  return ctx;
}

/** Must be called from inside a user gesture (tap) on mobile. */
export function unlockAudio(): Promise<void> {
  const c = getAudioContext();
  // iOS: playing a silent buffer inside the gesture fully unlocks output.
  const buf = c.createBuffer(1, 1, 22050);
  const src = c.createBufferSource();
  src.buffer = buf;
  src.connect(c.destination);
  src.start(0);
  return c.state === 'running' ? Promise.resolve() : c.resume();
}

/**
 * AudioContext time that is being HEARD at the given performance.now() time.
 * Uses getOutputTimestamp when available, which accounts for output latency,
 * so taps are compared with the sound the player actually hears.
 */
export function ctxTimeAt(c: AudioContext, perfMs: number = performance.now()): number {
  const ts = typeof c.getOutputTimestamp === 'function' ? c.getOutputTimestamp() : undefined;
  if (ts && ts.contextTime !== undefined && ts.performanceTime !== undefined && ts.performanceTime > 0) {
    return ts.contextTime + (perfMs - ts.performanceTime) / 1000;
  }
  return c.currentTime - (performance.now() - perfMs) / 1000;
}

export function loadLatencyMs(): number | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.latencyMs);
    if (raw === null) return null;
    const n = Number(raw);
    return Number.isFinite(n) ? n : null;
  } catch {
    return null;
  }
}

export function saveLatencyMs(ms: number): void {
  try {
    localStorage.setItem(STORAGE_KEYS.latencyMs, String(Math.round(ms)));
  } catch {
    /* storage unavailable: ignore */
  }
}

export function loadVibration(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEYS.vibration) !== 'off';
  } catch {
    return true;
  }
}

export function saveVibration(on: boolean): void {
  try {
    localStorage.setItem(STORAGE_KEYS.vibration, on ? 'on' : 'off');
  } catch {
    /* ignore */
  }
}

export function vibrate(ms: number): void {
  if (typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function') {
    navigator.vibrate(ms);
  }
}
