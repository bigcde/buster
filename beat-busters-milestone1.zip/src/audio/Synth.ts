// Procedural song: drums + bass + chord pad, synthesized with Web Audio.
// Uses the standard lookahead scheduler pattern. No audio files.
import { AUDIO } from '../config/constants';
import type { SongDef } from '../config/song';
import { secondsPerBeat } from '../core/beatMath';
import { sectionAt } from '../core/phases';

interface Bar {
  root: number; // bass root frequency (Hz)
  chord: number[]; // pad notes (Hz)
}

// Am - F - C - G
const BARS: Bar[] = [
  { root: 110.0, chord: [220.0, 261.63, 329.63] },
  { root: 87.31, chord: [174.61, 220.0, 261.63] },
  { root: 130.81, chord: [261.63, 329.63, 392.0] },
  { root: 98.0, chord: [196.0, 246.94, 293.66] },
];

const STEPS_PER_BEAT = 4; // 16th notes

export class Synth {
  private readonly master: GainNode;
  private readonly noise: AudioBuffer;
  private readonly stepDur: number;
  private readonly totalSteps: number;
  private nextStep = 0;
  private timer: number | null = null;

  constructor(
    private readonly ctx: AudioContext,
    private readonly song: SongDef,
    private readonly startTime: number,
  ) {
    this.master = ctx.createGain();
    this.master.gain.value = AUDIO.masterVolume;
    const comp = ctx.createDynamicsCompressor();
    this.master.connect(comp);
    comp.connect(ctx.destination);
    this.noise = makeNoise(ctx);
    this.stepDur = secondsPerBeat(song.bpm) / STEPS_PER_BEAT;
    this.totalSteps = Math.floor(song.durationSec / this.stepDur);
  }

  start(): void {
    this.schedule();
    this.timer = window.setInterval(() => this.schedule(), AUDIO.schedulerIntervalMs);
  }

  stop(): void {
    if (this.timer !== null) {
      window.clearInterval(this.timer);
      this.timer = null;
    }
  }

  /** Stop scheduling and quickly fade out anything already scheduled. */
  dispose(): void {
    this.stop();
    const now = this.ctx.currentTime;
    this.master.gain.cancelScheduledValues(now);
    this.master.gain.setTargetAtTime(0, now, 0.03);
    window.setTimeout(() => this.master.disconnect(), 400);
  }

  private schedule(): void {
    const horizon = this.ctx.currentTime + AUDIO.lookaheadSec;
    while (this.nextStep < this.totalSteps) {
      const t = this.startTime + this.nextStep * this.stepDur;
      if (t >= horizon) break;
      // Skip notes that are already in the past (e.g. tab was hidden).
      if (t >= this.ctx.currentTime - 0.05) this.playStep(this.nextStep, t);
      this.nextStep++;
    }
    if (this.nextStep >= this.totalSteps) this.stop();
  }

  private playStep(step: number, t: number): void {
    const songT = step * this.stepDur;
    const sec = sectionAt(songT, this.song);
    const name = sec.name;
    const p = (songT - sec.start) / (sec.end - sec.start); // progress in section
    const sub = step % STEPS_PER_BEAT;
    const beat = Math.floor(step / STEPS_PER_BEAT) % 4;
    const bar = BARS[Math.floor(step / (STEPS_PER_BEAT * 4)) % BARS.length];
    const spb = this.stepDur * STEPS_PER_BEAT;

    let vol = name === 'drop' ? 1.15 : 1;
    const fadeStart = this.song.durationSec - 8 * spb;
    if (songT > fadeStart) vol *= Math.max(0, (this.song.durationSec - songT) / (8 * spb));
    if (vol <= 0) return;

    // Kick: beats 1 & 3; four-on-the-floor in the drop and late build-up.
    const fourOnFloor = name === 'drop' || (name === 'buildup' && p > 0.5);
    if (sub === 0 && (fourOnFloor || beat === 0 || beat === 2)) this.kick(t, 0.9 * vol);

    // Snare: 2 & 4, or a roll that gets denser through the build-up.
    if (name === 'buildup') {
      const every = p < 0.33 ? 4 : p < 0.66 ? 2 : 1;
      if (step % every === 0) this.snare(t, (0.2 + 0.5 * p) * vol);
    } else if (name !== 'intro' && sub === 0 && (beat === 1 || beat === 3)) {
      this.snare(t, 0.6 * vol);
    }

    // Hi-hat: 8ths (offbeat only in the intro).
    if (sub === 2) this.hat(t, 0.16 * vol);
    else if (sub === 0 && name !== 'intro') this.hat(t, 0.09 * vol);

    // Bass.
    if (name !== 'intro') {
      if (sub === 0) this.bass(t, bar.root, spb * 0.45, 0.32 * vol);
      if (sub === 2 && name === 'drop') this.bass(t, bar.root * 2, spb * 0.3, 0.26 * vol);
      else if (sub === 2 && beat % 2 === 1) this.bass(t, bar.root, spb * 0.3, 0.22 * vol);
    }

    // Pad: one chord per bar; filter opens through the build-up.
    if (name !== 'intro' && step % (STEPS_PER_BEAT * 4) === 0) {
      const cutoff = name === 'buildup' ? 600 + 3400 * p : name === 'drop' ? 3200 : 1200;
      this.pad(t, bar.chord, spb * 4, cutoff, 0.07 * vol);
    }
  }

  // ---- instruments ----

  private envelope(g: GainNode, t: number, peak: number, attack: number, decay: number): void {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(peak, 0.0002), t + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
  }

  private noiseSource(): AudioBufferSourceNode {
    const s = this.ctx.createBufferSource();
    s.buffer = this.noise;
    return s;
  }

  private kick(t: number, v: number): void {
    const o = this.ctx.createOscillator();
    o.type = 'sine';
    o.frequency.setValueAtTime(150, t);
    o.frequency.exponentialRampToValueAtTime(45, t + 0.12);
    const g = this.ctx.createGain();
    this.envelope(g, t, v, 0.003, 0.28);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + 0.33);
  }

  private snare(t: number, v: number): void {
    const n = this.noiseSource();
    const hp = this.ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 1500;
    const g = this.ctx.createGain();
    this.envelope(g, t, v, 0.002, 0.16);
    n.connect(hp).connect(g).connect(this.master);
    n.start(t);
    n.stop(t + 0.2);

    const o = this.ctx.createOscillator();
    o.type = 'triangle';
    o.frequency.value = 190;
    const g2 = this.ctx.createGain();
    this.envelope(g2, t, v * 0.5, 0.002, 0.08);
    o.connect(g2).connect(this.master);
    o.start(t);
    o.stop(t + 0.12);
  }

  private hat(t: number, v: number): void {
    const n = this.noiseSource();
    const hp = this.ctx.createBiquadFilter();
    hp.type = 'highpass';
    hp.frequency.value = 7000;
    const g = this.ctx.createGain();
    this.envelope(g, t, v, 0.001, 0.05);
    n.connect(hp).connect(g).connect(this.master);
    n.start(t);
    n.stop(t + 0.08);
  }

  private bass(t: number, freq: number, dur: number, v: number): void {
    const o = this.ctx.createOscillator();
    o.type = 'sawtooth';
    o.frequency.value = freq;
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = 500;
    lp.Q.value = 4;
    const g = this.ctx.createGain();
    this.envelope(g, t, v, 0.005, dur);
    o.connect(lp).connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  private pad(t: number, freqs: number[], dur: number, cutoff: number, v: number): void {
    const lp = this.ctx.createBiquadFilter();
    lp.type = 'lowpass';
    lp.frequency.value = cutoff;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(v, t + 0.25);
    g.gain.setValueAtTime(v, t + dur - 0.2);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    lp.connect(g).connect(this.master);
    for (const f of freqs) {
      for (const detune of [-7, 7]) {
        const o = this.ctx.createOscillator();
        o.type = 'sawtooth';
        o.frequency.value = f;
        o.detune.value = detune;
        o.connect(lp);
        o.start(t);
        o.stop(t + dur + 0.05);
      }
    }
  }
}

/** Short click for calibration. */
export function playClick(ctx: AudioContext, t: number, freq: number, volume = 0.5): void {
  const o = ctx.createOscillator();
  o.type = 'sine';
  o.frequency.value = freq;
  const g = ctx.createGain();
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(volume, t + 0.002);
  g.gain.exponentialRampToValueAtTime(0.0001, t + 0.06);
  o.connect(g).connect(ctx.destination);
  o.start(t);
  o.stop(t + 0.08);
}

function makeNoise(ctx: AudioContext): AudioBuffer {
  const buf = ctx.createBuffer(1, ctx.sampleRate, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1;
  return buf;
}
