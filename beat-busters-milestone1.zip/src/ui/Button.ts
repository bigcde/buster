import Phaser from 'phaser';

/** Simple text button. Returns the text object (use getBounds() for hit tests). */
export function makeButton(
  scene: Phaser.Scene,
  x: number,
  y: number,
  label: string,
  onClick: () => void,
  fontSize = '22px',
): Phaser.GameObjects.Text {
  const btn = scene.add
    .text(x, y, label, {
      fontFamily: 'system-ui, sans-serif',
      fontSize,
      fontStyle: 'bold',
      color: '#ffffff',
      backgroundColor: '#3a3358',
      padding: { x: 16, y: 10 },
    })
    .setOrigin(0.5)
    .setDepth(60)
    .setInteractive({ useHandCursor: true });
  btn.on('pointerover', () => btn.setBackgroundColor('#544a80'));
  btn.on('pointerout', () => btn.setBackgroundColor('#3a3358'));
  btn.on('pointerup', onClick);
  return btn;
}
