import Phaser from 'phaser';

/**
 * A ring that shrinks onto a fixed target circle exactly on each beat.
 * Works with the sound off, so the beat is always visible.
 */
export class BeatRing {
  private readonly g: Phaser.GameObjects.Graphics;
  private flash = 0;

  constructor(
    scene: Phaser.Scene,
    private readonly x: number,
    private readonly y: number,
    private readonly radius = 46,
    private readonly color = 0xffd34d,
  ) {
    this.g = scene.add.graphics();
    this.g.setDepth(10);
  }

  /** Call on every new beat. */
  beat(): void {
    this.flash = 1;
  }

  /**
   * @param t song time (s)
   * @param spb seconds per beat
   * @param dtMs frame delta (ms)
   */
  update(t: number, spb: number, dtMs: number): void {
    const f = (((t % spb) + spb) % spb) / spb; // 0 on the beat .. 1 just before next
    const approach = this.radius + (1 - f) * this.radius * 1.3;
    this.flash = Math.max(0, this.flash - dtMs / 140);

    const g = this.g;
    g.clear();
    g.fillStyle(this.color, 0.12 + 0.4 * this.flash);
    g.fillCircle(this.x, this.y, this.radius * (1 + 0.08 * this.flash));
    g.lineStyle(4, this.color, 1);
    g.strokeCircle(this.x, this.y, this.radius);
    if (t > -spb) {
      g.lineStyle(3, 0xffffff, 0.3 + 0.7 * f);
      g.strokeCircle(this.x, this.y, approach);
    }
  }

  destroy(): void {
    this.g.destroy();
  }
}
