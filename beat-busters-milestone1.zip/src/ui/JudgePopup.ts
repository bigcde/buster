import Phaser from 'phaser';
import type { Judgement } from '../core/judge';

const COLORS: Record<Judgement, string> = {
  PERFECT: '#ffd34d',
  GOOD: '#7fd8ff',
  MISS: '#ff6b6b',
};

/** Floating PERFECT / GOOD / MISS text. */
export function showJudge(scene: Phaser.Scene, x: number, y: number, j: Judgement, offsetMs?: number): void {
  const label = offsetMs === undefined ? j : `${j}\n${offsetMs > 0 ? '+' : ''}${Math.round(offsetMs)} ms`;
  const text = scene.add
    .text(x, y, label, {
      fontFamily: 'system-ui, sans-serif',
      fontSize: j === 'PERFECT' ? '40px' : '32px',
      fontStyle: 'bold',
      color: COLORS[j],
      align: 'center',
      stroke: '#000000',
      strokeThickness: 6,
    })
    .setOrigin(0.5)
    .setDepth(50);

  if (j === 'PERFECT') {
    text.setScale(1.4);
    scene.tweens.add({ targets: text, scale: 1, duration: 120, ease: 'Back.easeOut' });
    scene.cameras.main.flash(80, 255, 220, 120, false);
  }

  scene.tweens.add({
    targets: text,
    y: y - 70,
    alpha: 0,
    delay: 250,
    duration: 500,
    ease: 'Quad.easeIn',
    onComplete: () => text.destroy(),
  });
}
