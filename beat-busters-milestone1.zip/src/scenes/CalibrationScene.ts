import Phaser from 'phaser';
import { CALIBRATION, GAME } from '../config/constants';
import { ctxTimeAt, getAudioContext, saveLatencyMs } from '../audio/context';
import { playClick } from '../audio/Synth';
import { median } from '../core/beatMath';
import { BeatRing } from '../ui/BeatRing';
import { makeButton } from '../ui/Button';

/**
 * Tap test: 4 lead-in clicks, then 8 clicks to tap along with.
 * Latency = median(tap time - nearest click time). Stored in localStorage.
 */
export class CalibrationScene extends Phaser.Scene {
  private ctx!: AudioContext;
  private startCtx = 0;
  private spb = 0;
  private clickTimes: number[] = [];
  private offsets: number[] = [];
  private ring!: BeatRing;
  private counter!: Phaser.GameObjects.Text;
  private info!: Phaser.GameObjects.Text;
  private skipBtn!: Phaser.GameObjects.Text;
  private lastBeat = -1;
  private finished = false;

  constructor() {
    super('Calibration');
  }

  create(): void {
    this.ctx = getAudioContext();
    this.spb = 60 / CALIBRATION.bpm;
    this.offsets = [];
    this.clickTimes = [];
    this.lastBeat = -1;
    this.finished = false;

    const cx = GAME.width / 2;
    this.add
      .text(cx, 90, 'KALİBRASYON', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '44px',
        fontStyle: 'bold',
        color: '#ffd34d',
      })
      .setOrigin(0.5);
    this.info = this.add
      .text(cx, 160, 'İlk 4 tıkı dinle, sonraki 8 tıkta ekrana dokun.', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '24px',
        color: '#ffffff',
        align: 'center',
      })
      .setOrigin(0.5);
    this.counter = this.add
      .text(cx, 520, '', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '28px',
        color: '#c9c2ea',
      })
      .setOrigin(0.5);

    this.ring = new BeatRing(this, cx, 360, 60);
    this.skipBtn = makeButton(this, GAME.width - 110, GAME.height - 50, 'Geç', () => this.finish(true));

    const total = CALIBRATION.leadInBeats + CALIBRATION.tapBeats;
    this.startCtx = this.ctx.currentTime + 0.8;
    for (let i = 0; i < total; i++) {
      const t = this.startCtx + i * this.spb;
      const isLeadIn = i < CALIBRATION.leadInBeats;
      playClick(this.ctx, t, isLeadIn ? 660 : 1100);
      if (!isLeadIn) this.clickTimes.push(t);
    }

    this.game.canvas.addEventListener('pointerdown', this.onPointerDown);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.game.canvas.removeEventListener('pointerdown', this.onPointerDown);
    });
  }

  private onPointerDown = (ev: PointerEvent): void => {
    if (this.finished) return;
    const x = this.scale.transformX(ev.pageX);
    const y = this.scale.transformY(ev.pageY);
    if (this.skipBtn.getBounds().contains(x, y)) return;

    const heard = ctxTimeAt(this.ctx, ev.timeStamp);
    if (heard < this.clickTimes[0] - this.spb / 2) return; // still in lead-in
    if (this.offsets.length >= CALIBRATION.tapBeats) return;

    let nearest = this.clickTimes[0];
    for (const c of this.clickTimes) {
      if (Math.abs(heard - c) < Math.abs(heard - nearest)) nearest = c;
    }
    const offsetMs = (heard - nearest) * 1000;
    if (Math.abs(offsetMs) <= CALIBRATION.maxTapOffsetMs) this.offsets.push(offsetMs);
  };

  update(_time: number, delta: number): void {
    const t = ctxTimeAt(this.ctx) - this.startCtx;
    this.ring.update(t, this.spb, delta);

    const beat = Math.floor(t / this.spb);
    if (beat !== this.lastBeat && t >= 0) {
      this.lastBeat = beat;
      this.ring.beat();
    }

    if (!this.finished) {
      const leadLeft = CALIBRATION.leadInBeats - Math.max(0, beat);
      this.counter.setText(
        t < 0 || leadLeft > 0
          ? `Dinle... ${Math.max(1, Math.min(CALIBRATION.leadInBeats, leadLeft))}`
          : `Dokunuş: ${this.offsets.length} / ${CALIBRATION.tapBeats}`,
      );
      const lastClick = this.clickTimes[this.clickTimes.length - 1];
      if (ctxTimeAt(this.ctx) > lastClick + this.spb) this.finish(false);
    }
  }

  private finish(skipped: boolean): void {
    if (this.finished) return;
    this.finished = true;

    let latency = 0;
    let msg: string;
    if (skipped) {
      msg = 'Kalibrasyon geçildi (0 ms).';
    } else if (this.offsets.length < CALIBRATION.minTaps) {
      msg = 'Yeterli dokunuş yok, 0 ms kullanılıyor.';
    } else {
      latency = median(this.offsets);
      msg = `Gecikme: ${Math.round(latency)} ms`;
    }
    saveLatencyMs(latency);
    this.info.setText(msg);
    this.counter.setText('');
    this.time.delayedCall(1400, () => this.scene.start('Match'));
  }
}
