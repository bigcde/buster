import Phaser from 'phaser';
import { GAME } from '../config/constants';
import { loadLatencyMs, unlockAudio } from '../audio/context';

export class BootScene extends Phaser.Scene {
  constructor() {
    super('Boot');
  }

  create(): void {
    const cx = GAME.width / 2;
    const cy = GAME.height / 2;

    this.add
      .text(cx, cy - 80, 'BEAT BUSTERS', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '72px',
        fontStyle: 'bold',
        color: '#ffd34d',
        stroke: '#000000',
        strokeThickness: 8,
      })
      .setOrigin(0.5);

    const hint = this.add
      .text(cx, cy + 40, 'Başlamak için dokun', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '28px',
        color: '#ffffff',
      })
      .setOrigin(0.5);
    this.tweens.add({ targets: hint, alpha: 0.35, duration: 700, yoyo: true, repeat: -1 });

    this.add
      .text(cx, GAME.height - 40, 'Prototip · Milestone 1 · Sesi aç, kulaklık önerilir', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '16px',
        color: '#8f87b3',
      })
      .setOrigin(0.5);

    this.input.once('pointerdown', () => {
      // resume() is called synchronously inside the gesture.
      void unlockAudio().then(() => {
        this.scene.start(loadLatencyMs() === null ? 'Calibration' : 'Match');
      });
    });
  }
}
