import Phaser from 'phaser';
import { AUDIO, FEEDBACK, GAME } from '../config/constants';
import { SECTION_LABELS, SONG, type SectionName } from '../config/song';
import { BeatClock } from '../audio/BeatClock';
import { Synth } from '../audio/Synth';
import { getAudioContext, loadLatencyMs, loadVibration, saveVibration, vibrate } from '../audio/context';
import { ComboTracker, judgeOffset, type Judgement } from '../core/judge';
import { isSongOver, phaseAt } from '../core/phases';
import { BeatRing } from '../ui/BeatRing';
import { showJudge } from '../ui/JudgePopup';
import { makeButton } from '../ui/Button';

const BAR = { x: 140, y: 34, w: 1000, h: 12 };
const GROUND_Y = 560;

/**
 * Milestone 1: song + beat ring + tap judging.
 * Units, towers, Groove and AI arrive in later milestones.
 */
export class MatchScene extends Phaser.Scene {
  private ctx!: AudioContext;
  private clock!: BeatClock;
  private synth!: Synth;
  private ring!: BeatRing;
  private combo!: ComboTracker;
  private counts: Record<Judgement, number> = { PERFECT: 0, GOOD: 0, MISS: 0 };
  private lastBeat = Number.NEGATIVE_INFINITY;
  private ended = false;
  private vibrationOn = true;
  private currentSection: SectionName | null = null;

  private progressFill!: Phaser.GameObjects.Rectangle;
  private sectionText!: Phaser.GameObjects.Text;
  private statsText!: Phaser.GameObjects.Text;
  private comboText!: Phaser.GameObjects.Text;
  private pulseTargets: Phaser.GameObjects.GameObject[] = [];
  private uiButtons: Phaser.GameObjects.Text[] = [];

  constructor() {
    super('Match');
  }

  create(): void {
    this.ctx = getAudioContext();
    this.combo = new ComboTracker();
    this.counts = { PERFECT: 0, GOOD: 0, MISS: 0 };
    this.lastBeat = Number.NEGATIVE_INFINITY;
    this.ended = false;
    this.currentSection = null;
    this.vibrationOn = loadVibration();
    this.uiButtons = [];
    this.pulseTargets = [];

    this.drawStage();
    this.drawTopBar();
    this.drawHud();

    this.ring = new BeatRing(this, GAME.width / 2, GAME.height - 70);

    // Start song.
    this.clock = new BeatClock(this.ctx, SONG.bpm, loadLatencyMs() ?? 0);
    const start = this.ctx.currentTime + AUDIO.startLeadSec;
    this.clock.start(start);
    this.synth = new Synth(this.ctx, SONG, start);
    this.synth.start();

    // Native listener so we get the exact event timestamp for judging.
    this.game.canvas.addEventListener('pointerdown', this.onPointerDown);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => {
      this.game.canvas.removeEventListener('pointerdown', this.onPointerDown);
      this.synth.dispose();
    });
  }

  // ---------- layout ----------

  private drawStage(): void {
    // Ground and placeholder towers (real towers come in Milestone 2).
    this.add.rectangle(GAME.width / 2, GROUND_Y + 80, GAME.width, 160, 0x1d1930);
    this.add.rectangle(GAME.width / 2, GROUND_Y, GAME.width, 2, 0x5b5280);

    const left = this.add.rectangle(140, GROUND_Y - 150, 200, 300).setStrokeStyle(3, 0x4f8cff);
    const right = this.add.rectangle(GAME.width - 140, GROUND_Y - 150, 200, 300).setStrokeStyle(3, 0xff5b6e);
    this.add.text(140, GROUND_Y - 150, 'SEN', { fontSize: '22px', color: '#4f8cff', fontStyle: 'bold' }).setOrigin(0.5);
    this.add
      .text(GAME.width - 140, GROUND_Y - 150, 'RAKİP', { fontSize: '22px', color: '#ff5b6e', fontStyle: 'bold' })
      .setOrigin(0.5);
    this.pulseTargets.push(left, right);

    const hint = this.add
      .text(GAME.width / 2, 300, 'Halka hedefe oturduğu anda ekrana dokun', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '26px',
        color: '#ffffff',
      })
      .setOrigin(0.5);
    this.tweens.add({ targets: hint, alpha: 0, delay: 6000, duration: 1000 });
  }

  private drawTopBar(): void {
    this.add.rectangle(BAR.x, BAR.y, BAR.w, BAR.h, 0x2a2540).setOrigin(0, 0.5);
    this.progressFill = this.add.rectangle(BAR.x, BAR.y, 0, BAR.h, 0xffd34d).setOrigin(0, 0.5);

    for (const s of SONG.sections) {
      const x0 = BAR.x + (s.start / SONG.durationSec) * BAR.w;
      const x1 = BAR.x + (s.end / SONG.durationSec) * BAR.w;
      if (s.name === 'drop') {
        this.add.rectangle(x0, BAR.y, x1 - x0, BAR.h + 6).setOrigin(0, 0.5).setStrokeStyle(2, 0xff8a3d);
      }
      if (s.start > 0) this.add.rectangle(x0, BAR.y, 2, BAR.h + 8, 0x8f87b3);
      this.add
        .text((x0 + x1) / 2, BAR.y + 20, SECTION_LABELS[s.name], {
          fontFamily: 'system-ui, sans-serif',
          fontSize: '13px',
          color: '#8f87b3',
        })
        .setOrigin(0.5, 0);
    }

    this.sectionText = this.add
      .text(GAME.width / 2, 100, '', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '34px',
        fontStyle: 'bold',
        color: '#ffffff',
      })
      .setOrigin(0.5);
  }

  private drawHud(): void {
    this.statsText = this.add.text(24, 70, '', {
      fontFamily: 'system-ui, sans-serif',
      fontSize: '18px',
      color: '#c9c2ea',
      lineSpacing: 4,
    });
    this.comboText = this.add
      .text(GAME.width / 2, 150, '', {
        fontFamily: 'system-ui, sans-serif',
        fontSize: '24px',
        fontStyle: 'bold',
        color: '#ffd34d',
      })
      .setOrigin(0.5);

    const vib = makeButton(this, GAME.width - 120, 84, this.vibLabel(), () => {
      this.vibrationOn = !this.vibrationOn;
      saveVibration(this.vibrationOn);
      vib.setText(this.vibLabel());
    }, '16px');
    const cal = makeButton(this, GAME.width - 120, 134, 'Kalibre et', () => this.scene.start('Calibration'), '16px');
    this.uiButtons.push(vib, cal);
    this.updateHud();
  }

  private vibLabel(): string {
    return `Titreşim: ${this.vibrationOn ? 'Açık' : 'Kapalı'}`;
  }

  private updateHud(): void {
    const c = this.counts;
    this.statsText.setText([`PERFECT  ${c.PERFECT}`, `GOOD     ${c.GOOD}`, `MISS     ${c.MISS}`]);
    const parts: string[] = [];
    if (this.combo.streak >= 2) parts.push(`Combo x${this.combo.streak}`);
    if (this.combo.onFire) parts.push('ON FIRE!');
    this.comboText.setText(parts.join('   '));
  }

  // ---------- input ----------

  private hitsUi(x: number, y: number): boolean {
    return this.uiButtons.some((b) => b.active && b.getBounds().contains(x, y));
  }

  private onPointerDown = (ev: PointerEvent): void => {
    if (this.ended) return;
    const x = this.scale.transformX(ev.pageX);
    const y = this.scale.transformY(ev.pageY);
    if (this.hitsUi(x, y)) return;

    const t = this.clock.songTime(ev.timeStamp);
    if (t < -this.clock.spb / 2) return; // before the first beat

    const offset = this.clock.offsetMs(t);
    const j = judgeOffset(offset);
    this.counts[j] += 1;
    this.combo.register(j);
    showJudge(this, x, y - 40, j, offset);
    this.updateHud();
  };

  // ---------- loop ----------

  update(_time: number, delta: number): void {
    const t = this.clock.songTime();
    this.ring.update(t, this.clock.spb, delta);

    if (t >= 0 && !this.ended) {
      const beat = this.clock.beatIndex(t);
      if (beat !== this.lastBeat) {
        this.lastBeat = beat;
        this.onBeat();
      }
    }

    const phase = phaseAt(Math.max(0, t));
    if (phase.section !== this.currentSection) {
      this.currentSection = phase.section;
      this.sectionText.setText(SECTION_LABELS[phase.section]);
      this.sectionText.setColor(phase.section === 'drop' ? '#ff8a3d' : '#ffffff');
      this.sectionText.setScale(1.3);
      this.tweens.add({ targets: this.sectionText, scale: 1, duration: 250, ease: 'Back.easeOut' });
    }

    const progress = Phaser.Math.Clamp(t / SONG.durationSec, 0, 1);
    this.progressFill.width = progress * BAR.w;

    if (!this.ended && isSongOver(t)) this.endSong();
  }

  private onBeat(): void {
    this.ring.beat();
    if (this.vibrationOn) vibrate(FEEDBACK.vibrateMs);
    // Beat pulse.
    this.tweens.add({ targets: this.pulseTargets, scale: 1.04, duration: 40, yoyo: true, ease: 'Quad.easeOut' });
  }

  private endSong(): void {
    this.ended = true;
    const c = this.counts;
    const total = c.PERFECT + c.GOOD + c.MISS;
    const pct = total > 0 ? Math.round((c.PERFECT / total) * 100) : 0;

    this.add.rectangle(GAME.width / 2, GAME.height / 2, 620, 340, 0x0d0b16, 0.92).setStrokeStyle(2, 0x5b5280).setDepth(70);
    this.add
      .text(
        GAME.width / 2,
        GAME.height / 2 - 70,
        [`Şarkı bitti`, `PERFECT ${c.PERFECT} · GOOD ${c.GOOD} · MISS ${c.MISS}`, `Perfect oranı %${pct} · En uzun combo ${this.combo.best}`],
        { fontFamily: 'system-ui, sans-serif', fontSize: '24px', color: '#ffffff', align: 'center', lineSpacing: 12 },
      )
      .setOrigin(0.5)
      .setDepth(71);

    const again = makeButton(this, GAME.width / 2 - 110, GAME.height / 2 + 100, 'Tekrar', () => this.scene.restart());
    const cal = makeButton(this, GAME.width / 2 + 110, GAME.height / 2 + 100, 'Kalibre et', () => this.scene.start('Calibration'));
    again.setDepth(72);
    cal.setDepth(72);
    this.uiButtons.push(again, cal);
  }
}
