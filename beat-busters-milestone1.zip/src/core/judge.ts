// Rhythm judging. No Phaser / DOM imports.
import { JUDGE, POWER } from '../config/constants';

export type Judgement = 'PERFECT' | 'GOOD' | 'MISS';

export interface JudgeWindows {
  perfectMs: number;
  goodMs: number;
}

/** Judge a drop by its signed offset (ms) from the nearest beat. */
export function judgeOffset(offsetMs: number, windows: JudgeWindows = JUDGE): Judgement {
  const abs = Math.abs(offsetMs);
  if (abs <= windows.perfectMs) return 'PERFECT';
  if (abs <= windows.goodMs) return 'GOOD';
  return 'MISS';
}

/** Unit power multiplier for a judgement (HP and damage). */
export function powerFor(j: Judgement): number {
  return POWER[j];
}

/** Extra beats of spawn delay for a judgement (MISS spawns one beat later). */
export function spawnDelayBeats(j: Judgement): number {
  return j === 'MISS' ? 1 : 0;
}

/**
 * Tracks PERFECT streaks.
 * Order per card drop: consumeDiscount(cost) first, then register(judgement).
 */
export class ComboTracker {
  streak = 0;
  best = 0;
  onFire = false;

  constructor(private readonly needed: number = JUDGE.comboForOnFire) {}

  register(j: Judgement): void {
    if (j === 'PERFECT') {
      this.streak += 1;
      this.best = Math.max(this.best, this.streak);
      if (this.streak >= this.needed) this.onFire = true;
    } else {
      this.streak = 0;
      this.onFire = false;
    }
  }

  /** Returns the cost to pay. Uses up ON FIRE if active. Never below 1. */
  consumeDiscount(cost: number): number {
    if (!this.onFire) return cost;
    this.onFire = false;
    this.streak = 0;
    return Math.max(1, cost - 1);
  }
}
