// Pure beat math. No Phaser / DOM imports.

export function secondsPerBeat(bpm: number): number {
  return 60 / bpm;
}

/** Index of the beat that has most recently started at time t (s). */
export function beatIndexAt(t: number, bpm: number): number {
  return Math.floor(t / secondsPerBeat(bpm));
}

/** Signed offset in ms from t to the nearest beat. Negative = early. */
export function nearestBeatOffsetMs(t: number, bpm: number): number {
  const spb = secondsPerBeat(bpm);
  const nearest = Math.round(t / spb);
  return (t - nearest * spb) * 1000;
}

/** Position inside the current beat, 0 (on the beat) .. 1 (just before next). */
export function beatFraction(t: number, bpm: number): number {
  const spb = secondsPerBeat(bpm);
  return (((t % spb) + spb) % spb) / spb;
}

export function median(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}
