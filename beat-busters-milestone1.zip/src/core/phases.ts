// Song section -> match phase. No Phaser / DOM imports.
import { GROOVE } from '../config/constants';
import { SONG, type Section, type SectionName, type SongDef } from '../config/song';

export interface PhaseInfo {
  section: SectionName;
  /** 0..1 progress inside the current section. */
  progress: number;
  grooveBeatsPerPoint: number;
  dropAbilityAvailable: boolean;
}

/** Section at song time t (s). Before 0 → first section, after end → last. */
export function sectionAt(t: number, song: SongDef = SONG): Section {
  const { sections } = song;
  if (t < sections[0].start) return sections[0];
  for (const s of sections) {
    if (t >= s.start && t < s.end) return s;
  }
  return sections[sections.length - 1];
}

export function phaseAt(t: number, song: SongDef = SONG): PhaseInfo {
  const s = sectionAt(t, song);
  const progress = Math.min(1, Math.max(0, (t - s.start) / (s.end - s.start)));
  const fast = s.name === 'buildup' || s.name === 'outro';
  return {
    section: s.name,
    progress,
    grooveBeatsPerPoint: fast ? GROOVE.fastBeatsPerPoint : GROOVE.normalBeatsPerPoint,
    dropAbilityAvailable: s.name === 'drop',
  };
}

export function isSongOver(t: number, song: SongDef = SONG): boolean {
  return t >= song.durationSec;
}
